<div class="blog_like">
	<?php if( function_exists('qode_like') ) qode_like(); ?>
</div>