<div>
	<?php echo do_shortcode('[no_social_share]'); ?>
</div>